/**
 * 
 * @author Ryan Beam
 * @author Brad Weiand
 * @author Ben Parsell
 * 
 * Eatery Class
 *
 */

package gameFoodCourt;

public class Eatery implements ClockListener {

	/** Eatery Queue **/
	private Queue<Person> eatLine = new Queue<Person>();
	
	/** Time until next event **/
	private int timeOfNextEvent = 0;
	
	/** Max queue length **/
	private int maxQlength = 0;
	
	/** Default Person object **/
	private Person person;
	
	/** Waiting line **/
	private WaitingLine line;
	
	/** Throughput **/
	private int completed = 0;
	
	/***************************************************
	 * 
	 * 	Constructor to setup waiting line to move into
	 * 	@param line waiting line
	 * 
	 **************************************************/
	public Eatery(WaitingLine line) {
		this.line = line;
	}
	
	/***************************************************
	 * 
	 * 	Helper method to add a person to eatery queue
	 * 	@param person object of type person
	 * 
	 **************************************************/
	public void add(Person person) {
		eatLine.enQ(person);
		maxQlength++;
	}
	
	/***************************************************
	 * 
	 * 	Helper method to implement ClockListener
	 * 	@param tick integer for clock time
	 * 
	 **************************************************/
	public void event(int tick) {
		if (tick >= timeOfNextEvent) {
			if (eatLine != null) { // Notice the delay that takes place here
				try {
					person = eatLine.deQ();
					line.add(person);

					timeOfNextEvent = tick + (int) (person.getEateryTime());
					maxQlength--;
					completed++;
				} catch (EmptyQException e) {
					e.printStackTrace();
				}
			}
		}
	}

	/***************************************************
	 * 
	 * 	Getter method for eatery queue size
	 * 	@return eatLine.size(); the size of queue
	 * 
	 **************************************************/
	public int getLeft() {
		return eatLine.size();
	}

	/***************************************************
	 * 
	 * 	Helper method to return max length of queue
	 * 	@return maxQlength the mac length of queue
	 * 
	 **************************************************/
	public int getMaxQlength() {
		return maxQlength;
	}

	/***************************************************
	 * 
	 * 	Helper method to return throughput
	 * @return completed integer for throughput
	 * 
	 **************************************************/
	public int getThroughPut() {
		return completed;
	}
}

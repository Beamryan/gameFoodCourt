package gameFoodCourt;

/**
 * @author Roger Ferguson
 */
public class Eatery implements ClockListener {

	private Queue<Person> eatLine = new Queue<Person>();
	private int timeOfNextEvent = 0;
	private int maxQlength = 0;
	private Person person;
	private WaitingLine line;
	private int completed = 0;
	
	public Eatery(WaitingLine line)
	{
		this.line = line;
	}

	public void add(Person person) {
		eatLine.enQ(person);
		maxQlength++;
	}

	public void event(int tick) {
		if (tick >= timeOfNextEvent) {
			if (eatLine.size() != 0) { // Notice the delay that takes place here
				try {
					person = eatLine.deQ();
					line.add(person);
					
					timeOfNextEvent = tick + (int) (person.getEateryTime());
					maxQlength--;
					completed++;
				} catch (EmptyQException e) {
					e.printStackTrace();
				}
			}
		}
	}

	public int getLeft() {
		return eatLine.size();
	}

	public int getMaxQlength() {
		return maxQlength;
	}

	public int getThroughPut() {
		return completed;
	}
}

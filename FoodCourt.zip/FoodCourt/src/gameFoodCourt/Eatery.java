package gameFoodCourt;
/**
 * @author   Roger Ferguson
 */
public class Eatery implements ClockListener {
	
	private Queue<Person> eatLine = new Queue<Person>();
	private WaitingLine wait;
	private int timeOfNextEvent = 0;
	private int maxQlength = 0;
	private Person person;
	private int completed = 0;
	
	public void add (Person person)
	{
		eatLine.enQ(person);
		maxQlength++;
	}
	
	public void event (int tick){
		if (tick >= timeOfNextEvent) {
			if (eatLine != null) {  // Notice the delay that takes place here
			try {
				person = eatLine.deQ();
				wait.add(person);
			} catch (EmptyQException e) {
				e.printStackTrace();
			}	
			timeOfNextEvent = tick + (int) (person.getEateryTime());
			maxQlength--;
			completed++;										
			}	
		}
	}
	
	public int getLeft() {
		return eatLine.size();
	}
	
	public int getMaxQlength() {
		return maxQlength;
	}

	public int getThroughPut() {
		return completed;
	}
}

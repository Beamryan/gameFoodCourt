/**
 * 
 * @author Ryan Beam
 * @author Brad Weiand
 * @author Ben Parsell
 * 
 * Eatery Class
 *
 */

package gameFoodCourt;

public class Eatery implements ClockListener {

	/** Eatery Queue */
	private Queue<Person> eatLine = new Queue<Person>();
	
	/** Time until next event */
	private int timeOfNextEvent = 0;
	
	/** Max queue length */
	private int maxQlength = 0;
	
	/** Default Person object */
	private Person person;
	
	/** Waiting line */
	private static WaitingLine line;
	
	/** Throughput */
	private int completed = 0;
	
	/***************************************************
	 * 
	 * 	Constructor to setup waiting line to move into
	 * 	@param line waiting line
	 * 
	 **************************************************/
	public Eatery(WaitingLine line) {
		Eatery.line = line;
	}
	
	/***************************************************
	 * 
	 * 	Helper method to add a person to eatery queue
	 * 	@param person object of type person
	 * 
	 **************************************************/
	public void add(Person person) {
		eatLine.enQ(person); // adds person to queue
		maxQlength++; // increases max queue length
	}
	
	/***************************************************
	 * 
	 * 	Helper method to implement ClockListener
	 * 	@param tick integer for clock time
	 * 
	 **************************************************/
	public void event(int tick) {
		if (tick >= timeOfNextEvent) {
			if (eatLine != null) { // if a person in queue
				try {
					person = eatLine.deQ(); // removes the person
					line.add(person); // add the person to waiting line

					timeOfNextEvent = tick + (int) (person.getEateryTime());
					maxQlength--;
					completed++; // person has finished eating
				} catch (EmptyQException e) {
					e.printStackTrace();
				}
			}
		}
	}

	/***************************************************
	 * 
	 * 	Getter method for eatery queue size
	 * 	@return Integer 
	 * 
	 **************************************************/
	public int getLeft() {
		return eatLine.size();
	}

	/***************************************************
	 * 
	 * 	Helper method to return max length of queue
	 * 	@return Integer
	 * 
	 **************************************************/
	public int getMaxQlength() {
		return maxQlength;
	}

	/***************************************************
	 * 
	 * 	Helper method to return throughput
	 * @return Integer
	 * 
	 **************************************************/
	public int getThroughPut() {
		return completed;
	}
}

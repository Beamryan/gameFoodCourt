/**
 * 
 * @author Ryan Beam
 * @author Brad Weiand
 * @author Ben Parsell
 *
 *	Queue Class
 */

package gameFoodCourt;

public class Queue<T> {
	
	/** Node for head of queue */
	private Node<T> head;
	
	/** Node for tail of queue */
	private Node<T> tail;
	
	/** Size of queue */
	private int size;
	

	/***************************************************
	 * 
	 * 	Default Constructor
	 * 
	 **************************************************/
	public Queue(){
		head = null;
		tail = null;
		size = 0;
	}

	@SuppressWarnings("hiding")
	private class Node<T>{
		protected T element;
		protected Node<T> next;
		
		protected Node(T element){
			this.element = element;
		}
	}

	/***************************************************
	 * 
	 * 	EnQueue method to add a node to front of Queue
	 * 	@param element Generic node
	 * 
	 **************************************************/
	public void enQ(T element){
		Node<T> t = new Node<T>(element);
		if(size==0){
			head = t;
			head.next = t;
			tail = t;
		} else {
			tail.next = t;
			tail = t;
		}
		size++;
	}

	/***************************************************
	 * 
	 * 	Dequeue method to remove end node
	 * 	@return	T
	 * 	@throws EmtpyQException 
	 * 
	 **************************************************/
	public T deQ() throws EmptyQException{
		if(size == 0){
			throw new EmptyQException("");
		}
		Node<T> temp = head;
		head = head.next;
		size--;
		return temp.element;
	}
	
	/***************************************************
	 * 
	 * 	Getter method to return size of Queue
	 * 	@return Integer
	 * 
	 **************************************************/
	public int size(){
		return size;
	}
}

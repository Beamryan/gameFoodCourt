/**
 * @author Roger Ferguson
 * 
 *  Clock class
 */
package gameFoodCourt;

public class Clock {

	/** The clock listeners */
	private ClockListener[] myListeners;
	
	/** The number of listeners */
	private int numListeners;
	
	/** The max number of listeners */
	private final int MAX = 100;

	/***************************************************
	 * 
	 * 	Default Constructor
	 * 
	 **************************************************/
	public Clock() {
		numListeners = 0;
		myListeners = new ClockListener[MAX];
	}

	/***************************************************
	 * 
	 * 	Main method to run clock for time duration
	 * 
	 **************************************************/
	public void run(int endingTime) {
		for (int currentTime = 0; currentTime <= endingTime; currentTime++) {
			for (int j = 0; j < numListeners; j++)
				myListeners[j].event(currentTime);
		}
	}

	/***************************************************
	 * 
	 * 	Helper method to add clock listeners
	 * 
	 **************************************************/
	public void add(ClockListener cl) {
		myListeners[numListeners] = cl;
		numListeners++;
	}

	/***************************************************
	 * 
	 * 	Helper method to get clock listeners
	 *  @return ClockListener[]
	 *  
	 **************************************************/
	public ClockListener[] getMyListeners() {
		return myListeners;
	}

	/***************************************************
	 * 
	 * 	Helper method to set clock Listeners
	 * 
	 **************************************************/
	public void setMyListeners(ClockListener[] myListeners) {
		this.myListeners = myListeners;
	}

	
	/***************************************************
	 * 
	 *  Helper method to get number of clock listeners
  	 *  @return Integer
	 * 
	 **************************************************/
	public int getNumListeners() {
		return numListeners;
	}

	/***************************************************
	 * 
	 *  Helper method to set number of clock listeners
	 * 
	 **************************************************/
	public void setNumListeners(int numListeners) {
		this.numListeners = numListeners;
	}

	/***************************************************
	 * 
	 *  Helper method to max number of clock listeners
  	 *  @return Integer
  	 *  
	 **************************************************/
	public int getMAX() {
		return MAX;
	}

}

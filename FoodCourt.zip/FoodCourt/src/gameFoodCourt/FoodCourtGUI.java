/**
 * 
 * @author Ryan Beam
 * @author Brad Weiand
 * @author Ben Parsell
 * 
 * @Project: Eatery Project 4
 * @version: winter 2017
 * @Date: 4/11/2017
 * @Description: This project runs a single clock that is watched by
 * multiple queues which implement listeners to perform events. Each
 * of these events move the person from destination to destination and
 * when the time has elapsed, output statistics are displayed showing
 * the given throughput of the destinations and program as a whole.
 *
 */

package gameFoodCourt;

import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import javax.swing.*;

/** Created by Ryan Beam */
public class FoodCourtGUI extends JFrame implements ActionListener {

	private static final long serialVersionUID = 1L;
	
	/** Person Producer array of Objects */
	private PersonProducer[] person;
	
	/** Array of eateries */
	private Eatery[] eateries;
	
	/** Checkout lines */
	private CheckOut checkout1;
	private CheckOut checkout2;

	/** Line between eateries and checkouts */
	private WaitingLine line;

	/** Statistic inputs */
	private int nextPerson, cashierAvgTime, totTime, eateryAvgTime, numOfEateries, numOfCheckouts = 2;
	
	/** Output variables */
	private int kitchenThroughput, theNumLeftInLine, theMaxCashierLine1, theMaxCashierLine2, maxPeople, totalCustomers;

	/** ArrayList of JTextFields */
	private ArrayList<JTextField> list;
	
	/** Main frame window */
	JFrame frame;

	/** Main Panel */
	JPanel infoPanel;
	JPanel outputPanel;
	JPanel buttonPanel;

	/** North field labels */
	JLabel inputLabel;
	JLabel secondsToNextPersonLabel;
	JLabel cashierAverageTimeLabel;
	JLabel totalTimeLabel;
	JLabel eateryAverageTimeLabel;
	JLabel timeToLeaveLabel;
	JLabel numEateriesLabel;

	/** North field text */
	JTextField secondsToNextPerson;
	JTextField cashierAverageTime;
	JTextField totalTime;
	JTextField eateryAverageTime;
	JTextField timeToLeave;
	JTextField numEateries;

	/** South field labels */
	JLabel outputLabel;
	JLabel throughputLabel;
	JLabel totalCustomersLabel;
	JLabel timeStartToFinishLabel;
	JLabel numLeftInLineLabel;
	JLabel maxCashierLineLabel;

	/** South field text */
	JTextField throughput;
	JTextField totCustomers;
	JTextField timeStartToFinish;
	JTextField numLeftInLine;
	JTextField maxCashierLine;

	/** Operating buttons */
	JButton start;
	JButton quit;

	/***************************************************
	 * 
	 * 	GUI Constructor 
	 * 	Calls simulation and layout helper methods 
	 * 
	 **************************************************/
	public FoodCourtGUI() {
		list = new ArrayList<JTextField>();
		addPanels();
		addNorthLayout();
		addSouthLayout();
		addButtons();
		frameSet();

		frame.setLocationRelativeTo(null);
	}

	/***************************************************
	 * 
	 * 	Simulation Helper Method
	 * 	Initializes the starting sim process
	 * 
	 **************************************************/
	public void runSimulation() {
		Clock clk = new Clock(); // add the clock

		eateries = new Eatery[numOfEateries]; // initiate array of eateries
		person = new PersonProducer[numOfEateries]; // person producer array

		checkout1 = new CheckOut(); // create the checkouts
		checkout2 = new CheckOut();
		line = new WaitingLine(checkout1, checkout2); // create the waiting line 
		for (int i = 0; i < numOfEateries; i++) {
			eateries[i] = new Eatery(line); // create each eatery and person producer
			person[i] = new PersonProducer(eateries[i], nextPerson, eateryAvgTime, cashierAvgTime);
			clk.add(eateries[i]); // then add eateries and persons to clock
			clk.add(person[i]);
		}
		clk.add(line); // add waiting line and checkouts to clock
		clk.add(checkout1);
		clk.add(checkout2);

		clk.run(totTime); // run clock for total time

	}

	/***************************************************
	 * 
	 * 	Helper method to add GUI JPanels
	 * 
	 **************************************************/
	private void addPanels() {
		infoPanel = new JPanel();
		infoPanel.setPreferredSize(new Dimension(400, 200));
		infoPanel.setAlignmentX(LEFT_ALIGNMENT);

		buttonPanel = new JPanel();
		buttonPanel.setPreferredSize(new Dimension(300, 60));
		buttonPanel.setAlignmentX(CENTER_ALIGNMENT);

		outputPanel = new JPanel();
		outputPanel.setPreferredSize(new Dimension(400, 200));
		outputPanel.setAlignmentX(LEFT_ALIGNMENT);
	}

	/***************************************************
	 * 
	 * 	Helper to add Labels and text fields for input 
	 * 
	 **************************************************/
	private void addNorthLayout() {
		inputLabel = new JLabel("--------------------------------Input Information--------------------------------");
		secondsToNextPersonLabel = new JLabel("Seconds to The Next Customer       ");
		cashierAverageTimeLabel = new JLabel("Seconds per Checkout                      ");
		totalTimeLabel = new JLabel("Total Simulation Time                         ");
		eateryAverageTimeLabel = new JLabel("Time at Eatery                                     ");
		timeToLeaveLabel = new JLabel("Time Before Giving Up                       ");
		numEateriesLabel = new JLabel("Number of Eateries                            ");

		secondsToNextPerson = new JTextField(15);
		list.add(secondsToNextPerson);
		cashierAverageTime = new JTextField(15);
		list.add(cashierAverageTime);
		totalTime = new JTextField(15);
		list.add(totalTime);
		eateryAverageTime = new JTextField(15);
		list.add(eateryAverageTime);
		timeToLeave = new JTextField(15);
		list.add(timeToLeave);
		numEateries = new JTextField(15);
		list.add(numEateries);

		infoPanel.add(inputLabel);

		infoPanel.add(secondsToNextPersonLabel);
		infoPanel.add(secondsToNextPerson);

		infoPanel.add(cashierAverageTimeLabel);
		infoPanel.add(cashierAverageTime);

		infoPanel.add(totalTimeLabel);
		infoPanel.add(totalTime);

		infoPanel.add(eateryAverageTimeLabel);
		infoPanel.add(eateryAverageTime);

		infoPanel.add(timeToLeaveLabel);
		infoPanel.add(timeToLeave);

		infoPanel.add(numEateriesLabel);
		infoPanel.add(numEateries);
	}

	/***************************************************
	 * 
	 * 	Helper Method adds statistic JLabels and
	 * 	Text fields
	 * 	  
	 **************************************************/
	private void addSouthLayout() {
		outputLabel = new JLabel("--------------------------------Output Information--------------------------------");
		throughputLabel = new JLabel("Table throughput:                          ");
		timeStartToFinishLabel = new JLabel("Average time per Person:          ");
		numLeftInLineLabel = new JLabel("Number of people in line:            ");
		maxCashierLineLabel = new JLabel("Max length cashier line:             ");
		totalCustomersLabel = new JLabel("Total Customers:                          ");

		throughput = new JTextField(15); // makes the output text fields
		totCustomers = new JTextField(15);
		timeStartToFinish = new JTextField(15);
		numLeftInLine = new JTextField(15);
		maxCashierLine = new JTextField(15);

		throughput.setEditable(false); // sets outputs to not editable
		totCustomers.setEditable(false);
		timeStartToFinish.setEditable(false);
		numLeftInLine.setEditable(false);
		maxCashierLine.setEditable(false);

		outputPanel.add(outputLabel); // adds the labels and text fields to panel

		outputPanel.add(throughputLabel);
		outputPanel.add(throughput);

		outputPanel.add(totalCustomersLabel);
		outputPanel.add(totCustomers);

		outputPanel.add(timeStartToFinishLabel);
		outputPanel.add(timeStartToFinish);

		outputPanel.add(numLeftInLineLabel);
		outputPanel.add(numLeftInLine);

		outputPanel.add(maxCashierLineLabel);
		outputPanel.add(maxCashierLine);
	}

	/***************************************************
	 * 
	 *  Helper method to add menu buttons and listeners 
	 * 
	 **************************************************/
	private void addButtons() {
		start = new JButton("Start Simulation"); // Create the operation buttons
		quit = new JButton("Quit Simulation"); 

		buttonPanel.add(start); // Add buttons to the panel
		buttonPanel.add(quit); 

		start.addActionListener(this); // Add buttons to action listener
		quit.addActionListener(this); 
	}

	/***************************************************
	 * 
	 * 	Helper method to setup the frame and border
	 *  layouts
	 * 
	 **************************************************/
	private void frameSet() {
		frame = new JFrame();

		BorderLayout theLayout = new BorderLayout(); // Initialize the layout
		frame.setLayout(theLayout);

		frame.add(infoPanel, BorderLayout.NORTH);
		frame.add(buttonPanel, BorderLayout.CENTER);
		frame.add(outputPanel, BorderLayout.SOUTH);

		frame.setPreferredSize(new Dimension(400, 480));
		frame.setResizable(false); // can't change frame size
		frame.setDefaultCloseOperation(EXIT_ON_CLOSE); // Set the close operation
		frame.pack(); // Pack the frame
		frame.setVisible(true); // Make the frame visible
	}

	/***************************************************
	 * 
	 * 	Action Performed
	 * 	@param e ActionEvent object
	 * 
	 **************************************************/
	public void actionPerformed(ActionEvent e) {
		JComponent buttonPressed = (JComponent) e.getSource();

		if (buttonPressed == start) {
			if (checkInputs()) { // values are valid
				resetStats(); // reset the statistics
				getValues(); // set the values
				runSimulation(); // run the simulation
				getStats(); // retrieve statistics
				changeText(); // change text fields
			} else {
				JOptionPane.showMessageDialog(null, "The values input are not valid.", "Warning",
						JOptionPane.WARNING_MESSAGE);
			}
		}

		if (buttonPressed == quit) {
			int n = JOptionPane.showConfirmDialog(null, "Are you sure you want to quit?", null,
					JOptionPane.YES_NO_OPTION);

			if (n == JOptionPane.YES_OPTION) // quits if user hits yes
				System.exit(0);
		}

	}
	
	/***************************************************
	 * 
	 * 	Helper method to grab user-input values 
	 * 
	 **************************************************/
	private void getValues() {
		nextPerson = Integer.parseInt(secondsToNextPerson.getText());
		cashierAvgTime = Integer.parseInt(cashierAverageTime.getText());
		totTime = Integer.parseInt(totalTime.getText());
		eateryAvgTime = Integer.parseInt(eateryAverageTime.getText());
		numOfEateries = Integer.parseInt(numEateries.getText()); 
	}
	
	/***************************************************
	 * 
	 * 	Helper method to reset output values 
	 * 
	 **************************************************/
	private void resetStats() {
		kitchenThroughput = 0;
		theNumLeftInLine = 0;
		theMaxCashierLine1 = 0;
		theMaxCashierLine2 = 0;
		maxPeople = 0;
		totalCustomers = 0;
	}
	
	/***************************************************
	 * 
	 * 	Helper method to change text values 
	 * 
	 **************************************************/
	private void changeText() {
		throughput.setText(kitchenThroughput + " people out of " + maxPeople);
		timeStartToFinish.setText((numOfCheckouts * (float)totTime /totalCustomers) + " seconds");
		numLeftInLine.setText(theNumLeftInLine + " people");
		maxCashierLine.setText("line 1: " + theMaxCashierLine1 + "  line 2: " + theMaxCashierLine2);
		totCustomers.setText(totalCustomers + " customers");
	}

	/***************************************************
	 * 
	 * 	Helper method to check user inputs
	 *  @return boolean
	 * 
	 **************************************************/
	private boolean checkInputs() {
		// checks all the JTextFiels to see if they're empty or not numeric
		for (JTextField j : list) {
			if (j.getText().trim().isEmpty()) {
				return false;
			}
			try {
				Integer.parseInt(j.getText());
			} catch (NumberFormatException e) {
				return false;
			}
		}

		return true;
	}
	
	/***************************************************
	 * 
	 * 	Helper method to get the statistics for panel
	 * 
	 **************************************************/
	private void getStats() {

		for (int i = 0; i < numOfEateries; i++) {
			kitchenThroughput += eateries[i].getThroughPut(); // people having eaten
			maxPeople += person[i].getMaxPeople(); // total created people
		}
		
		totalCustomers = (checkout1.getThroughPut() + checkout2.getThroughPut());
		theNumLeftInLine = line.getLeft(); // number left in waiting queue
		theMaxCashierLine1 = checkout1.getMaxQlength(); // max checkout line
		theMaxCashierLine2 = checkout2.getMaxQlength();
	}

	/***************************************************
	 * 
	 * 	Main method
	 * 	@param args[] command line arguments
	 * 
	 **************************************************/
	public static void main(String args[]) {
		FoodCourtGUI game = new FoodCourtGUI(); // Start the game
	}
}

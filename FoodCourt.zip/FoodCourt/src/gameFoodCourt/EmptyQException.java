package gameFoodCourt;

public class EmptyQException extends Exception {

	private static final long serialVersionUID = 1L;

	public EmptyQException(String message){
		super(message);
	}
}

/**
 * 
 * @author Ryan Beam
 * @author Brad Weiand
 * @author Ben Parsell
 * 
 * Exception for an empty Queue
 *
 */

package gameFoodCourt;

public class EmptyQException extends Exception {

	private static final long serialVersionUID = 1L;

	/***************************************************
	 * 
	 * 	Constructor to call on Message Class
	 * 	@param Message exception message
	 * 
	 **************************************************/
	public EmptyQException(String message){
		super(message);
	}
}

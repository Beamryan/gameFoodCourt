/**
 * @author Roger Ferguson
 * Edited by Ryan Beam, Ben Parsell, Brad Weiand
 * 
 */

package gameFoodCourt;

import java.util.Random;

public class PersonProducer implements ClockListener {
	
	/** Set time at eatery **/
	private int nextPerson = 0;
	
	/** Max amount of people **/
	private int maxPeople = 0;
	
	/** Eatery for person **/
	private Eatery eatery;
	
	/** Default person **/
	private Person person;
	
	/** Ticks till next person **/
	private int numOfTicksNextPerson;
	
	/** Average time person spends at eatery **/
	private int averageEateryTime;
	
	/** Average time spent at checkout **/
	private int averageCheckoutTime;
	
	/** Random object for determining type of person **/
	private Random r = new Random();

	/***************************************************
	 * 
	 * 	Constructor to initialize PersonProducer 
	 * 	attributes
	 * 
	 **************************************************/
	public PersonProducer(Eatery eatery, int numOfTicksNextPerson, int averageEateryTime, int averageCheckoutTime) {
		this.eatery = eatery;
		this.numOfTicksNextPerson = numOfTicksNextPerson;
		this.averageEateryTime = averageEateryTime;
		this.averageCheckoutTime = averageCheckoutTime;
	}
	
	/***************************************************
	 * 
	 * 	Event helper for ClockListener interface
	 * 	@param tick integer for clock time
	 * 
	 **************************************************/
	public void event(int tick) {
		float num = r.nextFloat();

		if (num >= 0 && num <= .1) {
			person = new SpecialNeedsPerson(); /* change to special needs person */
		}

		else if (num > .1 && num <= .3) {
			person = new LimitedTimePerson(); /* change to limited time person */
		}

		else
			person = new RegularPerson();

		if (nextPerson <= tick) {
			nextPerson = tick + numOfTicksNextPerson;

			person.setEateryTime(averageEateryTime * 0.5 * r.nextGaussian() + averageEateryTime + .5);
			person.setCheckoutTime(averageCheckoutTime * 0.5 * r.nextGaussian() + averageCheckoutTime + .5);
			person.setTickTime(tick);
			person.setDestination(eatery);
			eatery.add(person);
			maxPeople++;
		}
	}
	
	/***************************************************
	 * 
	 * 	Helper method to return max people produced
	 * 	@return maxPeople int of max people
	 * 
	 **************************************************/
	public int getMaxPeople()
	{
		return maxPeople;
	}

}

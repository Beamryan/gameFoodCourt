/**
 * 
 */
package gameFoodCourt;

import java.util.Random;

/**
 * @author Roger Ferguson
 */
public class PersonProducer implements ClockListener {

	private int nextPerson = 0;
	private int maxPeople = 0;
	private Eatery eatery;
	private Person person;
	private int numOfTicksNextPerson;
	private int averageEateryTime;
	private int averageCheckoutTime;

	private Random r = new Random();

	public PersonProducer(Eatery eatery, int numOfTicksNextPerson, int averageEateryTime, int averageCheckoutTime) {
		this.eatery = eatery;
		this.numOfTicksNextPerson = numOfTicksNextPerson;
		this.averageEateryTime = averageEateryTime;
		this.averageCheckoutTime = averageCheckoutTime;
	}

	public void event(int tick) {
		float num = r.nextFloat();

		if (num >= 0 && num <= .1) {
			person = new SpecialNeedsPerson(); /* change to special needs person */
		}

		else if (num > .1 && num <= .3) {
			person = new LimitedTimePerson(); /* change to limited time person */
		}

		else
			person = new RegularPerson();

		if (nextPerson <= tick) {
			nextPerson = tick + numOfTicksNextPerson;

			person.setEateryTime(averageEateryTime * 0.5 * r.nextGaussian() + averageEateryTime + .5);
			person.setCheckoutTime(averageCheckoutTime * 0.5 * r.nextGaussian() + averageCheckoutTime + .5);
			person.setTickTime(tick);
			person.setDestination(eatery);
			eatery.add(person);
			maxPeople++;
		}
	}
	
	public int getMaxPeople()
	{
		return maxPeople;
	}

}

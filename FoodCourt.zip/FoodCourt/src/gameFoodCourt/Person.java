package gameFoodCourt;

public class Person {
	private int tickTime;
	private double eateryTime;
	private double checkoutTime;
	private double leaveTime;
	private Eatery Destination;
	
	public Person(int tickTime, double eateryTime, double leaveTime, double checkoutTime) {
		this.tickTime = tickTime;
		this.eateryTime = eateryTime;
		this.leaveTime = leaveTime;
		this.checkoutTime = checkoutTime;
	}	
	
	public Person() {
	}

	public void setTickTime(int tick) {
		this.tickTime = tick;
	}
	
	public int getTickTime() {
		return tickTime;
	}

	public void setDestination(Eatery eatery) {
		this.Destination = eatery;
	}

	public Eatery getDestination() {
		return Destination;
	}

	public void setEateryTime(double e) {
		this.eateryTime = e;	
	}
	
	public double getEateryTime() {
		return eateryTime;
	}
	
	public void setCheckoutTime(double c) {
		this.checkoutTime = c;	
	}
	
	public double getCheckoutTime() {
		return checkoutTime;
	}
	
	public void setLeaveTime(double l) {
		this.leaveTime = l;	
	}
	
	public double getLeaveTime() {
		return leaveTime;
	}
}
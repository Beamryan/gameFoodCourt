/**
 * 
 * @author Ryan Beam
 * @author Brad Weiand
 * @author Ben Parsell
 *
 *	Main person class
 */

package gameFoodCourt;

public class Person {
	
	/** Clock time for specific person **/
	private int tickTime;
	
	/** Set time at eatery **/
	private double eateryTime;
	
	/** Set time at checkout **/
	private double checkoutTime;
	
	/** Set time before leaving angrily **/
	private double leaveTime;
	
	/** Set destination or eatery **/
	private Eatery Destination;
	
	/***************************************************
	 * 
	 * 	Constructor to initialize Person attributes
	 * 	@param tickTime int for clock time
	 *	@param eateryTime double for time at eatery
	 *	@param leaveTime double time before person leaves
	 *	@param checkoutTime double time for checkout
	 * 
	 **************************************************/
	public Person(int tickTime, double eateryTime, double leaveTime, double checkoutTime) {
		this.tickTime = tickTime;
		this.eateryTime = eateryTime;
		this.leaveTime = leaveTime;
		this.checkoutTime = checkoutTime;
	}	
	
	/***************************************************
	 * 
	 * 	Default Constructor
	 * 
	 **************************************************/
	public Person() {
	}
	
	/***************************************************
	 * 
	 * 	Helper method to set Person's tick time 
	 * 	@param tick integer of clock time
	 * 
	 **************************************************/
	public void setTickTime(int tick) {
		this.tickTime = tick;
	}
	
	/***************************************************
	 * 
	 * 	Getter Method to return current tickTime
	 * 	@return Integer
	 * 
	 **************************************************/
	public int getTickTime() {
		return tickTime;
	}
	
	/***************************************************
	 * 
	 *  Helper method to set Person's destination
	 *  @param eatery the desired eatery
	 * 
	 **************************************************/
	public void setDestination(Eatery eatery) {
		this.Destination = eatery;
	}

	/***************************************************
	 * 
	 * 	Getter method to return eatery
	 * 	@return Eatery
	 * 
	 **************************************************/
	public Eatery getDestination() {
		return Destination;
	}
	
	/***************************************************
	 * 
	 * 	Helper method to set time spent at eatery
	 * 	@param e double for eatery time for clock
	 * 
	 **************************************************/
	public void setEateryTime(double e) {
		this.eateryTime = e;	
	}
	
	/***************************************************
	 * 
	 * 	Getter method for the current eatery time
	 * 	@return double
	 * 
	 **************************************************/
	public double getEateryTime() {
		return eateryTime;
	}
	
	/***************************************************
	 * 
	 * 	Helper method to set the time for checkout line
	 * 	@param c double clock time for checkout
	 * 
	 **************************************************/
	public void setCheckoutTime(double c) {
		this.checkoutTime = c;	
	}
	
	/***************************************************
	 * 
	 * 	Getter method to return set checkout time
	 * 	@return double
	 * 
	 **************************************************/
	public double getCheckoutTime() {
		return checkoutTime;
	}
	
	/***************************************************
	 * 
	 * 	Helper method to set the person's leave time, 
	 * 	or when they get upset and walk away
	 * 	@param l double amount of time to leave
	 * 
	 **************************************************/
	public void setLeaveTime(double l) {
		this.leaveTime = l;	
	}
	
	/***************************************************
	 * 
	 * 	Getter method to return set leave time
	 * 	@return double
	 * 
	 **************************************************/
	public double getLeaveTime() {
		return leaveTime;
	}
}
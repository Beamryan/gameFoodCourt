/**
 * 
 * @author Ryan Beam
 * @author Brad Weiand
 * @author Ben Parsell
 *
 *	Special Needs person class
 */

package gameFoodCourt;

public class SpecialNeedsPerson extends Person {
	
	/***************************************************
	 * 
	 * 	Constructor to call parent class and 
	 * 	initialize attributes
	 * 	@param tickTime int for clock time
	 *	@param eateryTime double for time at eatery
	 *	@param leaveTime double time before person leaves
	 *	@param checkoutTime double time for checkout
	 * 
	 **************************************************/
	public SpecialNeedsPerson(int tickTime, double eateryTime, double leaveTime, double cashiersTime) {
		super(tickTime, eateryTime*4, leaveTime*3, cashiersTime*2);
	}
	
	/***************************************************
	 * 
	 * 	Default Constructor
	 * 
	 **************************************************/
	public SpecialNeedsPerson(){
		
	}
}
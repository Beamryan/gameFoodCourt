/**
 * 
 * @author Ryan Beam
 * @author Brad Weiand
 * @author Ben Parsell
 * 
 * CheckOut Queue class
 *
 */

package gameFoodCourt;

public class CheckOut implements ClockListener {

	/** Queue for checkout lines */
	private Queue<Person> checkoutLine = new Queue<Person>();
	
	/** Till next event happens */
	private int timeOfNextEvent = 0;
	
	/** Integer of max size for queue */
	private int maxQlength = 0;
	
	/** Default person object */
	private Person person;
	
	/** Total customers */
	private int totalCustomers = 0;

	/***************************************************
	 * 
	 * 	Helper method to add a person to the checkout
	 * 	queue
	 * 	@param person an object of type person	
	 * 
	 **************************************************/
	public void add(Person person) {
		checkoutLine.enQ(person); // add person to queue
		maxQlength++;
	}

	/***************************************************
	 * 
	 * 	Event method to implement 
	 * 	ClockListener interface
	 * 	@param tick integer (clock time)
	 * 	
	 **************************************************/
	public void event(int tick) {
		if (tick >= timeOfNextEvent) {
			if (checkoutLine != null) { // if person in queue
				try {
					person = checkoutLine.deQ(); // remove person
					timeOfNextEvent = tick + (int) (person.getCheckoutTime());
					maxQlength--;
					totalCustomers++; // add a customer
				} catch (EmptyQException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	/***************************************************
	 * 
	 * 	Helper method to return current checkout size
	 * 	@return Integer
	 * 	
	 **************************************************/
	public int getLeft() {
		return checkoutLine.size();
	}

	/***************************************************
	 * 
	 * 	Helper method to return the max length of Queue
	 * 	@return Integer
	 * 
	 **************************************************/
	public int getMaxQlength() {
		return maxQlength;
	}

	/***************************************************
	 * 
	 * 	Helper method to return total customers that 
	 * 	have gone through line
	 * 	@return Integer
	 * 
	 **************************************************/
	public int getThroughPut() {
		return totalCustomers;
	}
}
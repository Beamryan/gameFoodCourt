package gameFoodCourt;

public class CheckOut implements ClockListener {
	
	private Queue<Person> checkoutLine = new Queue<Person>();
	private int timeOfNextEvent = 0; 
	private int maxQlength = 0;
	private Person person;
	private int totalCustomers = 0;
	
	public void add(Person person)
	{
		checkoutLine.enQ(person);
		maxQlength++;
	}
	
	public void event (int tick){
		if (tick >= timeOfNextEvent) {
			if (checkoutLine != null) {  // Notice the delay that takes place here
				try {
					person = checkoutLine.deQ();
				} catch (EmptyQException e) {
					e.printStackTrace();
				}	
				timeOfNextEvent = tick + (int) (person.getEateryTime());
				maxQlength--;
				totalCustomers++;										
				}		
		}
	}
	
	public int getLeft() {
		return checkoutLine.size();
	}
	
	public int getMaxQlength() {
		return maxQlength;
	}

	public int getThroughPut() {
		return totalCustomers;
	}
}
/**
 * 
 * @author Ryan Beam
 * @author Brad Weiand
 * @author Ben Parsell
 *
 *	Regular person class
 */

package gameFoodCourt;

public class RegularPerson extends Person {
	
	/***************************************************
	 * 
	 * 	Constructor to call parent class and 
	 * 	initialize attributes
	 * 	@param tickTime int for clock time
	 *	@param eateryTime double for time at eatery
	 *	@param leaveTime double time before person leaves
	 *	@param checkoutTime double time for checkout
	 * 
	 **************************************************/
	public RegularPerson(int tickTime, double eateryTime, double leaveTime, double checkoutTime) {
		super(tickTime, eateryTime, leaveTime, checkoutTime);
	}
	
	/***************************************************
	 * 
	 * 	Default Constructor
	 * 
	 **************************************************/
	public RegularPerson()
	{
		
	}
}
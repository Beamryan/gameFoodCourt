package gameFoodCourt;

public class RegularPerson extends Person {
	
	public RegularPerson(int tickTime, double eateryTime, double leaveTime, double checkoutTime) {
		super(tickTime, eateryTime, leaveTime, checkoutTime);
	}
	
	public RegularPerson()
	{
		
	}
}
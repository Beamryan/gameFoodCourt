/**
 * 
 * @author Roger Ferguson
 * 
 * Clock Listener Interface
 *
 */

package gameFoodCourt;

public interface ClockListener 
{
	/***************************************************
	 * 
	 *  Only method on interface; listens to clock on event
	 * 
	 **************************************************/
	public void event(int tick);
}

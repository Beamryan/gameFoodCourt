/**
 * 
 * @author Roger Ferguson
 * 
 * Clock Listener Interface
 *
 */

package gameFoodCourt;

public interface ClockListener 
{
	public void event(int tick);
}

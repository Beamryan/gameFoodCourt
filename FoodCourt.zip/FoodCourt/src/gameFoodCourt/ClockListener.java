package gameFoodCourt;

public interface ClockListener 
{
	public void event(int tick);
}

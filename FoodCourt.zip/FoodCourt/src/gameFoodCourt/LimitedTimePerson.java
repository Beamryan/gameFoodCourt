/**
 * 
 * @author Ryan Beam
 * @author Brad Weiand
 * @author Ben Parsell
 * 
 * Person with limited time
 *
 */

package gameFoodCourt;

public class LimitedTimePerson extends Person {
	
	/***************************************************
	 * 
	 * 	Constructor to call parent class and 
	 * 	initialize attributes
	 * 	@param tickTime int for clock time
	 *	@param eateryTime double for time at eatery
	 *	@param leaveTime double time before person leaves
	 *	@param checkoutTime double time for checkout
	 * 
	 **************************************************/
	public LimitedTimePerson(int tickTime, double eateryTime, double leaveTime, double checkoutTime) {
		super(tickTime, ( (int) eateryTime) * 0.5, ( (int) leaveTime) * 0.5, checkoutTime);
	}
	
	/***************************************************
	 * 
	 * 	Default Constructor
	 * 
	 **************************************************/
	public LimitedTimePerson(){
		
	}
}
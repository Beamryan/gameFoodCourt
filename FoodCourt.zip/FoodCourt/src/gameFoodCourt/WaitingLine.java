package gameFoodCourt;

import java.util.Random;

public class WaitingLine implements ClockListener{
	private Queue<Person> waiting = new Queue<Person>();
	private CheckOut check1; 
	private CheckOut check2;
	private int timeOfNextEvent = 0;
	private int maxQlength = 0;
	private Person person;
	private int completed = 0;
	
	Random r = new Random();
	
	public void add(Person person)
	{
		waiting.enQ(person);
		maxQlength++;
	}
	
	public void event (int tick){
		if (tick >= timeOfNextEvent) {
			if (waiting != null) {  // Notice the delay that takes place here
			try {
				person = waiting.deQ();
				int choice = r.nextInt(2);
				if(choice == 0)
					check1.add(person);
				else
					check2.add(person);
			} catch (EmptyQException e) {
				e.printStackTrace();
			}	
			timeOfNextEvent = tick + (int) (person.getEateryTime());
			maxQlength--;
			completed++;										
			}	
		}
	}
	
	public int getThroughPut() {
		return completed;
	}
	
	public int getLeft() {
		return waiting.size();
	}
	
	public int getMaxQlength() {
		return maxQlength;
	}
	
}

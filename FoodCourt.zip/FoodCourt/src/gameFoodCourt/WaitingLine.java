package gameFoodCourt;

import java.util.Random;

public class WaitingLine implements ClockListener {
	private Queue<Person> waiting = new Queue<Person>();
	private int timeOfNextEvent = 0;
	private int maxQlength = 0;
	private CheckOut checkout1;
	private CheckOut checkout2;
	private Person person;
	private int completed = 0;
	Random r = new Random();
	
	public WaitingLine(CheckOut checkout1, CheckOut checkout2)
	{
		this.checkout1 = checkout1;
		this.checkout2 = checkout2;
	}

	public void add(Person person) {
		waiting.enQ(person);
		maxQlength++;
	}

	public void event(int tick) {
		if (tick >= timeOfNextEvent) {
			if (waiting != null) { // Notice the delay that takes place here
				try {
					person = waiting.deQ();
					int choice = r.nextInt(2);
					if (choice == 0)
						checkout1.add(person);
					else
						checkout2.add(person);

					timeOfNextEvent = tick + (int) (person.getEateryTime());
					maxQlength--;
					completed++;
				} catch (EmptyQException e) {
					e.printStackTrace();
				}
			}
		}
	}

	public int getThroughPut() {
		return completed;
	}

	public int getLeft() {
		return waiting.size();
	}

	public int getMaxQlength() {
		return maxQlength;
	}

}

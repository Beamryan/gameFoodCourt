/**
 * 
 * @author Ryan Beam
 * @author Brad Weiand
 * @author Ben Parsell
 *
 *	Waiting Line class
 */

package gameFoodCourt;

import java.util.Random;

public class WaitingLine implements ClockListener {
	
	/** Main waiting line Queue **/
	private Queue<Person> waiting = new Queue<Person>();
	
	/** Clock time until next event **/
	private int timeOfNextEvent = 0;
	
	/** Max for line size **/
	private int maxQlength = 0;
	
	/** Two Checkout Queues **/
	private CheckOut checkout1;
	private CheckOut checkout2;
	
	/** Default Person object **/
	private Person person;
	
	/** Throughput for line **/
	private int completed = 0;
	
	/** Random object for choosing line **/
	Random r = new Random();
	
	/***************************************************
	 * 
	 * 	Constructor to setup checkout lines to
	 *  advance into
	 * 
	 **************************************************/
	public WaitingLine(CheckOut checkout1, CheckOut checkout2)
	{
		this.checkout1 = checkout1;
		this.checkout2 = checkout2;
	}
	
	/***************************************************
	 * 
	 * 	Helper method to add person to Queue
	 * 	@param person a Person object
	 * 
	 **************************************************/
	public void add(Person person) {
		waiting.enQ(person);
		maxQlength++;
	}
	
	/***************************************************
	 * 
	 * Method to implement ClockListener interface
	 * Will add person to checkoutline upon leaving
	 * waiting line
	 * @param tick integer for clock time
	 * 
	 **************************************************/
	public void event(int tick) {
		if (tick >= timeOfNextEvent) {
			if (waiting != null) { // Notice the delay that takes place here
				try {
					person = waiting.deQ();
					int choice = r.nextInt(2);
					if (choice == 0)
						checkout1.add(person);
					else
						checkout2.add(person);

					timeOfNextEvent = tick + (int) (person.getEateryTime());
					maxQlength--;
					completed++;
				} catch (EmptyQException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	/***************************************************
	 * 
	 * Getter method for throughput of line
	 * @return completed int of number people served
	 * 
	 **************************************************/
	public int getThroughPut() {
		return completed;
	}
	
	/***************************************************
	 * 
	 * 	Getter method to return size of waiting line
	 * 	@return waiting line size
	 * 
	 **************************************************/
	public int getLeft() {
		return waiting.size();
	}

	/***************************************************
	 * 
	 * 	Getter method to get the set max Queue length
	 * 	@return maxQlength integer for max size
	 * 
	 **************************************************/
	public int getMaxQlength() {
		return maxQlength;
	}

}
